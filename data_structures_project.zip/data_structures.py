
# Data Structures Project in Python
# Features: Stack, Queue, Linked List

# -------- STACK --------
class Stack:
    def __init__(self):
        self.stack = []

    def push(self, data):
        self.stack.append(data)
        print(f"{data} pushed to Stack")

    def pop(self):
        if not self.stack:
            print("Stack is empty!")
        else:
            print(f"{self.stack.pop()} popped from Stack")

    def display(self):
        print("Stack:", self.stack)

# -------- QUEUE --------
class Queue:
    def __init__(self):
        self.queue = []

    def enqueue(self, data):
        self.queue.append(data)
        print(f"{data} added to Queue")

    def dequeue(self):
        if not self.queue:
            print("Queue is empty!")
        else:
            print(f"{self.queue.pop(0)} removed from Queue")

    def display(self):
        print("Queue:", self.queue)

# -------- LINKED LIST --------
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def insert(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
        else:
            temp = self.head
            while temp.next:
                temp = temp.next
            temp.next = new_node
        print(f"{data} inserted into Linked List")

    def display(self):
        temp = self.head
        if not temp:
            print("Linked List is empty!")
            return
        print("Linked List:", end=" ")
        while temp:
            print(temp.data, end=" -> ")
            temp = temp.next
        print("None")

# -------- MAIN MENU --------
def main():
    stack = Stack()
    queue = Queue()
    linked_list = LinkedList()

    while True:
        print("\n==== Data Structure Project ====")
        print("1. Stack - Push")
        print("2. Stack - Pop")
        print("3. Stack - Display")
        print("4. Queue - Enqueue")
        print("5. Queue - Dequeue")
        print("6. Queue - Display")
        print("7. Linked List - Insert")
        print("8. Linked List - Display")
        print("9. Exit")

        choice = input("Enter your choice: ")

        if choice == '1':
            stack.push(input("Enter value to push: "))
        elif choice == '2':
            stack.pop()
        elif choice == '3':
            stack.display()
        elif choice == '4':
            queue.enqueue(input("Enter value to enqueue: "))
        elif choice == '5':
            queue.dequeue()
        elif choice == '6':
            queue.display()
        elif choice == '7':
            linked_list.insert(input("Enter value to insert: "))
        elif choice == '8':
            linked_list.display()
        elif choice == '9':
            print("Exiting...")
            break
        else:
            print("Invalid choice! Try again.")

if __name__ == "__main__":
    main()
